Jiayi Zhou (jz697) , Kaiyan Xiao (kx58)

We assume vertices (with x=0,z>0) on the outer surface have the texture coordinate u=0(or u=1), 
as the web page does not give specific value of the start end of the outer surface.  

We create sphere.obj, cylinder.obj, torus.obj with the option (n=32,m=16,r=0.25,if used), and save them in Framework.
We also use torusHighNF.obj to test converter and create a torusHighNFsmooth.obj, which you could see the effect in p3d.in.   