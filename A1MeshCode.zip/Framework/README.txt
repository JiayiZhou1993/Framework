Place your exported meshgen.jar in this folder and run the batch script
Mac users can use "source test.bat" to run the test
Smoothed outputs will be generated in the "out" folder
